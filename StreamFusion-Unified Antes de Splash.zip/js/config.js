const firebaseConfig = {
  apiKey: "AIzaSyBNeedBwkLS_U0a048mZ233DSM-bMh789U",
  authDomain: "streamfusion-app.firebaseapp.com",
  projectId: "streamfusion-app",
  storageBucket: "streamfusion-app.firebasestorage.app",
  messagingSenderId: "1023470476009",
  appId: "1:1023470476009:web:f398cd8daf7cf55b782e78",
  measurementId: "G-35C7CJHLKB"
};

const API_KEY = '32e5e53999e380a0291d66fb304153fe';

const ADMIN_EMAIL = 'javiervelasquez0618@gmail.com';

export { firebaseConfig, API_KEY, ADMIN_EMAIL };
